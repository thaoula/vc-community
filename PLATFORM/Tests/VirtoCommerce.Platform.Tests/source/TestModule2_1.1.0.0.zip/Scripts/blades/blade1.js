﻿angular.module('testModule2.blades.blade1', [])
.controller('tm2-blade1Controller', ['$scope', 'bladeNavigationService', function ($scope, bladeNavigationService) {

	$scope.data = "testModule2 content";
	$scope.blade.title = "testModule2 title";
    $scope.blade.isLoading = false;
}]);
