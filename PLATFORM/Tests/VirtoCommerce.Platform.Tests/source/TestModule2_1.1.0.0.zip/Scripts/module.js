﻿//Call this to register our module to main application
var moduleTemplateName = "platformWebApp.testModule2";

if (AppDependencies != undefined) {
    AppDependencies.push(moduleTemplateName);
}

angular.module(moduleTemplateName, [
    'testModule2.blades.blade1'
])
.config(
  ['$stateProvider',
    function ($stateProvider) {
        $stateProvider
            .state('workspace.testModule2Template', {
            	url: '/testModule2',
            	templateUrl: 'Modules/$(TestModule2)/Scripts/home/home.tpl.html',
                controller: [
                    '$scope', 'bladeNavigationService', function ($scope, bladeNavigationService) {
                        var blade = {
                            id: 'blade1',
                            // controller name must be unique in Application. Use prefix like 'um-'.
                            controller: 'tm2-blade1Controller',
                            template: 'Modules/$(TestModule2)/Scripts/blades/blade1.tpl.html',
                            isClosingDisabled: true
                        };
                        bladeNavigationService.showBlade(blade);
                    }
                ]
            });
    }
  ]
)
.run(
  ['$rootScope', 'mainMenuService', function ($rootScope, mainMenuService) {
      //Register module in main menu
      var menuItem = {
          group: 'Browse',
          icon: 'glyphicon glyphicon-search',
          title: 'Test Module 2',
          priority: 110,
          state: 'workspace.testModule2Template',
          permission: 'TestModule2Permission'
      };
      mainMenuService.addMenuItem(menuItem);
  }]);